package com.yape.builders;

import com.yape.config.TestConfig;
import com.yape.models.account.AccountRequest;
import com.yape.models.account.AccountRequest.Filter;

public class AccountRequestBuilder {
    
    private String phoneNumber;
    private Filter[] filters;
    
    private AccountRequestBuilder() {}
    
    public static AccountRequestBuilder aValidRequest() {
        AccountRequestBuilder builder = new AccountRequestBuilder();
        builder.phoneNumber = TestConfig.get().getTestPhone();
        return builder;
    }
    
    public static AccountRequestBuilder anInvalidRequest() {
        AccountRequestBuilder builder = new AccountRequestBuilder();
        builder.phoneNumber = "invalid_phone";
        return builder;
    }
    
    public AccountRequestBuilder withPhone(String phoneNumber) {
        this.phoneNumber = phoneNumber;
        return this;
    }
    
    public AccountRequestBuilder withFilters(Filter... filters) {
        this.filters = filters;
        return this;
    }
    
    public AccountRequestBuilder withPersonalInfoFilter() {
        this.filters = new Filter[]{Filter.PERSONAL_INFORMATION};
        return this;
    }
    
    public AccountRequestBuilder withContactInfoFilter() {
        this.filters = new Filter[]{Filter.CONTACT_INFORMATION};
        return this;
    }
    
    public AccountRequestBuilder withoutFilters() {
        this.filters = null;
        return this;
    }
    
    public AccountRequest build() {
        AccountRequest.AccountRequestBuilder requestBuilder = AccountRequest.builder()
                .phoneNumber(phoneNumber);
        
        if (filters != null && filters.length > 0) {
            requestBuilder.filters(filters);
        }
        
        return requestBuilder.build();
    }
}
