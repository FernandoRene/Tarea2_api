package com.yape.config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class TestConfig {
    
    private static TestConfig instance;
    private Properties properties;
    private final String environment;
    
    private TestConfig() {
        this.environment = System.getProperty("env", "dev");
        loadProperties();
    }
    
    public static TestConfig get() {
        if (instance == null) {
            synchronized (TestConfig.class) {
                if (instance == null) {
                    instance = new TestConfig();
                }
            }
        }
        return instance;
    }
    
    private void loadProperties() {
        properties = new Properties();
        String configFile = String.format("config/%s.properties", environment);
        
        try (InputStream input = getClass().getClassLoader().getResourceAsStream(configFile)) {
            if (input == null) {
                throw new RuntimeException("Config file not found: " + configFile);
            }
            properties.load(input);
        } catch (IOException e) {
            throw new RuntimeException("Error loading config: " + configFile, e);
        }
    }
    
    // URLs
    public String getBaseUrl() {
        return properties.getProperty("base.url");
    }
    
    public String getAccountBasePath() {
        return properties.getProperty("account.base.path");
    }
    
    public String getRemittanceBasePath() {
        return properties.getProperty("remittance.base.path");
    }
    
    // Headers
    public String getAuthHeader() {
        return properties.getProperty("auth.header");
    }
    
    public String getChannel() {
        return properties.getProperty("channel");
    }
    
    public String getPublicToken() {
        return properties.getProperty("public.token");
    }
    
    public String getAppUserId() {
        return properties.getProperty("app.user.id");
    }
    
    // Test Data
    public String getTestPhone() {
        return properties.getProperty("test.phone.number");
    }
    
    public String getTestAccount() {
        return properties.getProperty("test.account.number");
    }
    
    // Timeouts
    public int getDefaultTimeout() {
        return Integer.parseInt(properties.getProperty("default.timeout", "5000"));
    }
    
    public int getCreateTimeout() {
        return Integer.parseInt(properties.getProperty("create.timeout", "30000"));
    }
    
    public String getEnvironment() {
        return environment;
    }
}
