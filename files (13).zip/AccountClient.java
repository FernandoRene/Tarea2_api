package com.yape.clients;

import com.yape.models.account.AccountRequest;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import static io.restassured.RestAssured.given;

public class AccountClient extends BaseClient {
    
    private static final String ACCOUNTS_ENDPOINT = "/accounts";
    
    public AccountClient() {
        super(TestConfig.get().getAccountBasePath());
    }
    
    public Response getAccount(AccountRequest request) {
        // Account API requiere headers adicionales
        RequestSpecification accountSpec = new RequestSpecBuilder()
                .addRequestSpecification(baseSpec)
                .addHeader("PublicToken", config.getPublicToken())
                .addHeader("AppUserId", config.getAppUserId())
                .build();
        
        return given()
                .spec(accountSpec)
                .body(request)
                .when()
                .post(ACCOUNTS_ENDPOINT)
                .then()
                .log().ifValidationFails()
                .extract()
                .response();
    }
    
    // Método simplificado para tests rápidos
    public Response getAccount(String phoneNumber, String filterFields) {
        AccountRequest request = AccountRequest.builder()
                .phoneNumber(phoneNumber)
                .filterFields(filterFields)
                .build();
        return getAccount(request);
    }
    
    // Método con enums para type-safety
    public Response getAccount(String phoneNumber, AccountRequest.Filter... filters) {
        AccountRequest request = AccountRequest.builder()
                .phoneNumber(phoneNumber)
                .filters(filters)
                .build();
        return getAccount(request);
    }
}
