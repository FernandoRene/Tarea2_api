package com.yape.base;

public class TestTags {
    
    // Test Levels
    public static final String SMOKE = "smoke";
    public static final String REGRESSION = "regression";
    public static final String EXTENDED = "extended";
    
    // API Types
    public static final String ACCOUNT = "account";
    public static final String REMITTANCE = "remittance";
    
    // Test Types
    public static final String HAPPY_PATH = "happy-path";
    public static final String ERROR_HANDLING = "error-handling";
    public static final String PERFORMANCE = "performance";
    public static final String CONTRACT = "contract";
}
