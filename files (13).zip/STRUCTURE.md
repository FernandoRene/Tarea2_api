# 📁 Estructura del Proyecto

```
automation-yape/
│
├── 📄 README.md                          ← Empieza aquí
├── 📄 COMMANDS.md                        ← Comandos útiles
├── ⚙️ pom.xml                            ← Maven config
│
├── 📂 docs/
│   └── ADR.md                            ← Decisiones arquitectónicas
│
├── 📂 src/main/java/com/yape/
│   │
│   ├── 📂 clients/                       ← Capa de comunicación API
│   │   ├── BaseClient.java               │ Config común RestAssured
│   │   └── AccountClient.java            │ Métodos específicos Account
│   │
│   ├── 📂 models/                        ← DTOs (request/response)
│   │   └── account/
│   │       └── AccountRequest.java       │ Con enum de filtros
│   │
│   ├── 📂 validators/                    ← Validadores reutilizables
│   │   └── ResponseValidator.java        │ API fluent para assertions
│   │
│   ├── 📂 builders/                      ← Test data builders
│   │   └── AccountRequestBuilder.java    │ Fluent builder para requests
│   │
│   └── 📂 config/
│       └── TestConfig.java               │ Singleton para config
│
├── 📂 src/test/java/com/yape/
│   │
│   ├── 📂 smoke/                         ← 3 tests (~30 seg)
│   │   └── AccountSmokeTest.java         │ Tests críticos
│   │
│   ├── 📂 regression/                    ← 12 tests (~3-5 min)
│   │   └── AccountFiltersRegressionTest.java
│   │       ├── IndividualFilters         │ 4 tests
│   │       ├── BusinessCriticalCombinations │ 3 tests
│   │       └── EdgeCases                 │ 2 tests
│   │
│   └── 📂 base/
│       ├── BaseTest.java                 │ Setup común
│       └── TestTags.java                 │ Constantes de tags
│
└── 📂 src/test/resources/
    │
    ├── 📂 config/                        ← Config por ambiente
    │   ├── dev.properties                │ Development
    │   └── cert.properties               │ Certification
    │
    └── 📂 schemas/                       ← 3 schemas JSON
        ├── account-base-schema.json      │ Todos los tests ✅
        ├── account-full-schema.json      │ Test sin filtros ✅
        └── error-response-schema.json    │ Tests de error ✅
```

## 🎯 Flujo de Uso

```
1. Setup
   └── TestConfig.java carga dev.properties

2. Test ejecuta
   └── BaseTest.java inicializa AccountClient
       └── AccountClient hereda de BaseClient
           └── BaseClient configura RestAssured

3. Request
   └── AccountRequestBuilder.aValidRequest()
       └── .withPersonalInfoFilter()
           └── .build() → AccountRequest

4. API Call
   └── accountClient.getAccount(request)
       └── BaseClient.post("/accounts", request)

5. Validation
   └── ResponseValidator.assertThat(response)
       ├── .isSuccess()
       ├── .hasValidBaseStructure() ← Schema
       ├── .hasFields("firstName")   ← Código
       └── .doesNotHaveFields("email") ← Código

6. Reporte
   └── Allure genera evidencia
```

## 🔄 Extensión para Remittance

```
PASO 1: Crear modelo
└── models/remittance/
    ├── ValidateRequest.java
    ├── CreateRequest.java
    └── InquireRequest.java

PASO 2: Crear cliente
└── clients/
    └── RemittanceClient.java extends BaseClient

PASO 3: Crear tests
└── test/
    ├── smoke/RemittanceSmokeTest.java
    └── regression/RemittanceRegressionTest.java

PASO 4: Agregar schemas (si necesario)
└── schemas/
    └── remittance-*.json
```

## 📊 Archivos Clave por Función

### Para ejecutar tests:
```
COMMANDS.md               ← Todos los comandos
src/test/.../AccountSmokeTest.java
src/test/.../AccountFiltersRegressionTest.java
```

### Para entender validación híbrida:
```
validators/ResponseValidator.java    ← Código
schemas/account-base-schema.json     ← Schema base
schemas/account-full-schema.json     ← Schema completo
```

### Para crear requests:
```
builders/AccountRequestBuilder.java
models/account/AccountRequest.java
```

### Para configurar ambientes:
```
config/TestConfig.java
resources/config/dev.properties
resources/config/cert.properties
```

### Para entender arquitectura:
```
docs/ADR.md                  ← Decisiones clave
README.md                    ← Overview general
```

## 🎨 Patrones Visualizados

### Builder Pattern
```
AccountRequestBuilder
    .aValidRequest()
    .withPersonalInfoFilter()
    .build()
        ↓
    AccountRequest
```

### Fluent Validation
```
ResponseValidator
    .assertThat(response)
    .isSuccess()
    .hasValidBaseStructure()
    .hasFields(...)
    .doesNotHaveFields(...)
```

### Herencia de Clientes
```
      BaseClient
         ↑
    ┌────┴────┐
    │         │
AccountClient RemittanceClient
```

### Estrategia Híbrida
```
        Test
         │
    ┌────┴────┐
    │         │
Schema Base  Validación
(estructura) Programática
             (campos)
```
