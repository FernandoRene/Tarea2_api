package com.yape.smoke;

import com.yape.base.BaseTest;
import com.yape.base.TestTags;
import com.yape.builders.AccountRequestBuilder;
import com.yape.models.account.AccountRequest;
import io.qameta.allure.*;
import io.restassured.response.Response;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import static com.yape.models.account.AccountRequest.Filter.*;
import static com.yape.validators.ResponseValidator.assertThat;

@Epic("Account API")
@Feature("Smoke Tests")
@Tag(TestTags.SMOKE)
@Tag(TestTags.ACCOUNT)
class AccountSmokeTest extends BaseTest {
    
    @Test
    @DisplayName("Get account without filters returns complete information")
    @Description("Valida que sin filtros se retorna toda la información del cliente")
    @Severity(SeverityLevel.BLOCKER)
    @Story("Account Lookup - Complete Profile")
    void getAccount_withoutFilters_returnsCompleteInfo() {
        // Arrange
        AccountRequest request = AccountRequestBuilder.aValidRequest()
                .withoutFilters()
                .build();
        
        // Act
        Response response = accountClient.getAccount(request);
        
        // Assert - Validación con SCHEMA COMPLETO
        assertThat(response)
                .isSuccess()
                .hasValidFullStructure()
                .respondsWithin5Seconds();
    }
    
    @Test
    @DisplayName("Get account with personal info filter returns only personal fields")
    @Description("Valida el filtro más común en producción: personalInformation")
    @Severity(SeverityLevel.BLOCKER)
    @Story("Account Lookup - Personal Info")
    void getAccount_withPersonalInfoFilter_returnsOnlyPersonalFields() {
        // Arrange
        AccountRequest request = AccountRequestBuilder.aValidRequest()
                .withPersonalInfoFilter()
                .build();
        
        // Act
        Response response = accountClient.getAccount(request);
        
        // Assert - Schema base + validación programática
        assertThat(response)
                .isSuccess()
                .hasValidBaseStructure()
                .hasFields("personalInformation.firstName", 
                          "personalInformation.lastName")
                .doesNotHaveFields("contactInformation", 
                                  "accountInformation")
                .respondsWithin5Seconds();
    }
    
    @Test
    @DisplayName("Get account with invalid phone number returns 400 error")
    @Description("Validación básica de error handling")
    @Severity(SeverityLevel.CRITICAL)
    @Story("Account Lookup - Error Handling")
    void getAccount_withInvalidPhone_returns400() {
        // Arrange
        AccountRequest request = AccountRequestBuilder.anInvalidRequest()
                .withPersonalInfoFilter()
                .build();
        
        // Act
        Response response = accountClient.getAccount(request);
        
        // Assert - Validación con SCHEMA DE ERROR
        assertThat(response)
                .isBadRequest()
                .hasValidErrorStructure();
    }
}
