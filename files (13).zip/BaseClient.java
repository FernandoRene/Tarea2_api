package com.yape.clients;

import com.yape.config.TestConfig;
import io.qameta.allure.restassured.AllureRestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

import static io.restassured.RestAssured.given;

public abstract class BaseClient {
    
    protected RequestSpecification baseSpec;
    protected String basePath;
    protected TestConfig config;
    
    protected BaseClient(String basePath) {
        this.basePath = basePath;
        this.config = TestConfig.get();
        this.baseSpec = buildBaseSpec();
    }
    
    private RequestSpecification buildBaseSpec() {
        return new RequestSpecBuilder()
                .setBaseUri(config.getBaseUrl())
                .setBasePath(basePath)
                .setContentType(ContentType.JSON)
                .addHeader("Authorization", config.getAuthHeader())
                .addHeader("Channel", config.getChannel())
                .addHeader("X-Correlation-Id", generateCorrelationId())
                .addHeader("Request-Date", generateRequestDate())
                .addFilter(new AllureRestAssured())
                .log(LogDetail.ALL)
                .build();
    }
    
    protected Response post(String endpoint, Object body) {
        return given()
                .spec(baseSpec)
                .header("X-Correlation-Id", generateCorrelationId()) // Nuevo por request
                .body(body)
                .when()
                .post(endpoint)
                .then()
                .log().ifValidationFails()
                .extract()
                .response();
    }
    
    protected Response get(String endpoint) {
        return given()
                .spec(baseSpec)
                .header("X-Correlation-Id", generateCorrelationId())
                .when()
                .get(endpoint)
                .then()
                .log().ifValidationFails()
                .extract()
                .response();
    }
    
    private String generateCorrelationId() {
        return UUID.randomUUID().toString();
    }
    
    private String generateRequestDate() {
        return ZonedDateTime.now().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME);
    }
}
