package com.yape.regression;

import com.yape.base.BaseTest;
import com.yape.base.TestTags;
import com.yape.builders.AccountRequestBuilder;
import com.yape.models.account.AccountRequest;
import io.qameta.allure.*;
import io.restassured.response.Response;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static com.yape.models.account.AccountRequest.Filter.*;
import static com.yape.validators.ResponseValidator.assertThat;

@Epic("Account API")
@Feature("Account Filters")
@Tag(TestTags.REGRESSION)
@Tag(TestTags.ACCOUNT)
class AccountFiltersRegressionTest extends BaseTest {
    
    // ========== GRUPO A: Filtros Individuales ==========
    
    @Nested
    @DisplayName("Individual Filters")
    class IndividualFilters {
        
        @Test
        @DisplayName("Personal information filter only")
        @Severity(SeverityLevel.CRITICAL)
        void personalInformationOnly() {
            AccountRequest request = AccountRequestBuilder.aValidRequest()
                    .withFilters(PERSONAL_INFORMATION)
                    .build();
            
            Response response = accountClient.getAccount(request);
            
            assertThat(response)
                    .isSuccess()
                    .hasValidBaseStructure()
                    .hasFields("personalInformation.firstName",
                              "personalInformation.lastName")
                    .doesNotHaveFields("contactInformation",
                                      "accountInformation",
                                      "addressInformation");
        }
        
        @Test
        @DisplayName("Contact information filter only")
        @Severity(SeverityLevel.CRITICAL)
        void contactInformationOnly() {
            AccountRequest request = AccountRequestBuilder.aValidRequest()
                    .withFilters(CONTACT_INFORMATION)
                    .build();
            
            Response response = accountClient.getAccount(request);
            
            assertThat(response)
                    .isSuccess()
                    .hasValidBaseStructure()
                    .hasFields("contactInformation.email",
                              "contactInformation.phoneNumber")
                    .doesNotHaveFields("personalInformation",
                                      "accountInformation",
                                      "addressInformation");
        }
        
        @Test
        @DisplayName("Account information filter only")
        @Severity(SeverityLevel.NORMAL)
        void accountInformationOnly() {
            AccountRequest request = AccountRequestBuilder.aValidRequest()
                    .withFilters(ACCOUNT_INFORMATION)
                    .build();
            
            Response response = accountClient.getAccount(request);
            
            assertThat(response)
                    .isSuccess()
                    .hasValidBaseStructure()
                    .hasFields("accountInformation.accountNumber")
                    .doesNotHaveFields("personalInformation",
                                      "contactInformation",
                                      "addressInformation");
        }
        
        @Test
        @DisplayName("Address information filter only")
        @Severity(SeverityLevel.NORMAL)
        void addressInformationOnly() {
            AccountRequest request = AccountRequestBuilder.aValidRequest()
                    .withFilters(ADDRESS_INFORMATION)
                    .build();
            
            Response response = accountClient.getAccount(request);
            
            assertThat(response)
                    .isSuccess()
                    .hasValidBaseStructure()
                    .hasFields("addressInformation.addressLine1")
                    .doesNotHaveFields("personalInformation",
                                      "contactInformation",
                                      "accountInformation");
        }
    }
    
    // ========== GRUPO B: Combinaciones Críticas de Negocio ==========
    
    @Nested
    @DisplayName("Business Critical Combinations")
    class BusinessCriticalCombinations {
        
        @Test
        @DisplayName("Personal + Contact for KYC validation")
        @Description("Combinación más común para validación KYC básica")
        @Severity(SeverityLevel.CRITICAL)
        @Story("KYC Validation")
        void personalAndContact_forKYC() {
            AccountRequest request = AccountRequestBuilder.aValidRequest()
                    .withFilters(PERSONAL_INFORMATION, CONTACT_INFORMATION)
                    .build();
            
            Response response = accountClient.getAccount(request);
            
            assertThat(response)
                    .isSuccess()
                    .hasValidBaseStructure()
                    .hasFields("personalInformation.firstName",
                              "personalInformation.lastName",
                              "contactInformation.email",
                              "contactInformation.phoneNumber")
                    .doesNotHaveFields("accountInformation",
                                      "addressInformation");
        }
        
        @Test
        @DisplayName("Personal + Account for onboarding")
        @Description("Combinación común durante el proceso de onboarding")
        @Severity(SeverityLevel.CRITICAL)
        @Story("Customer Onboarding")
        void personalAndAccount_forOnboarding() {
            AccountRequest request = AccountRequestBuilder.aValidRequest()
                    .withFilters(PERSONAL_INFORMATION, ACCOUNT_INFORMATION)
                    .build();
            
            Response response = accountClient.getAccount(request);
            
            assertThat(response)
                    .isSuccess()
                    .hasValidBaseStructure()
                    .hasFields("personalInformation.firstName",
                              "accountInformation.accountNumber")
                    .doesNotHaveFields("contactInformation",
                                      "addressInformation");
        }
        
        @Test
        @DisplayName("Personal + Contact + Account for complete profile")
        @Description("Perfil completo del cliente sin información de dirección")
        @Severity(SeverityLevel.NORMAL)
        @Story("Customer Profile")
        void personalContactAccount_forCompleteProfile() {
            AccountRequest request = AccountRequestBuilder.aValidRequest()
                    .withFilters(PERSONAL_INFORMATION, 
                               CONTACT_INFORMATION, 
                               ACCOUNT_INFORMATION)
                    .build();
            
            Response response = accountClient.getAccount(request);
            
            assertThat(response)
                    .isSuccess()
                    .hasValidBaseStructure()
                    .hasFields("personalInformation.firstName",
                              "contactInformation.email",
                              "accountInformation.accountNumber")
                    .doesNotHaveFields("addressInformation");
        }
    }
    
    // ========== GRUPO C: Edge Cases ==========
    
    @Nested
    @DisplayName("Edge Cases")
    class EdgeCases {
        
        @Test
        @DisplayName("All filters together")
        @Severity(SeverityLevel.NORMAL)
        void allFiltersTogether() {
            AccountRequest request = AccountRequestBuilder.aValidRequest()
                    .withFilters(PERSONAL_INFORMATION,
                               CONTACT_INFORMATION,
                               ACCOUNT_INFORMATION,
                               ADDRESS_INFORMATION)
                    .build();
            
            Response response = accountClient.getAccount(request);
            
            // Con todos los filtros, debería ser igual que sin filtros
            assertThat(response)
                    .isSuccess()
                    .hasValidFullStructure()
                    .hasFields("personalInformation.firstName",
                              "contactInformation.email",
                              "accountInformation.accountNumber",
                              "addressInformation.addressLine1");
        }
        
        @Test
        @DisplayName("Invalid filter is ignored gracefully")
        @Severity(SeverityLevel.MINOR)
        void invalidFilter_isIgnored() {
            // Enviar filtro inválido directamente
            Response response = accountClient.getAccount(
                    config.getTestPhone(),
                    "invalidFilter,personalInformation"
            );
            
            // Debería retornar solo personal info, ignorando el filtro inválido
            assertThat(response)
                    .isSuccess()
                    .hasValidBaseStructure();
        }
    }
    
    // ========== Tests Parametrizados para Combinaciones Críticas ==========
    
    @ParameterizedTest(name = "{0}")
    @MethodSource("criticalFilterCombinations")
    @DisplayName("Critical filter combinations")
    @Severity(SeverityLevel.CRITICAL)
    void criticalFilterCombinations(
            String scenario,
            AccountRequest.Filter[] filters,
            String[] expectedFields,
            String[] unexpectedFields) {
        
        // Arrange
        AccountRequest request = AccountRequestBuilder.aValidRequest()
                .withFilters(filters)
                .build();
        
        // Act
        Response response = accountClient.getAccount(request);
        
        // Assert
        ResponseValidator validator = assertThat(response)
                .isSuccess()
                .hasValidBaseStructure();
        
        if (expectedFields.length > 0) {
            validator.hasFields(expectedFields);
        }
        
        if (unexpectedFields.length > 0) {
            validator.doesNotHaveFields(unexpectedFields);
        }
    }
    
    static Stream<Arguments> criticalFilterCombinations() {
        return Stream.of(
                Arguments.of(
                        "Personal Info Only",
                        new AccountRequest.Filter[]{PERSONAL_INFORMATION},
                        new String[]{"personalInformation.firstName"},
                        new String[]{"contactInformation", "accountInformation"}
                ),
                Arguments.of(
                        "Contact Info Only",
                        new AccountRequest.Filter[]{CONTACT_INFORMATION},
                        new String[]{"contactInformation.email"},
                        new String[]{"personalInformation", "accountInformation"}
                ),
                Arguments.of(
                        "Personal + Contact (KYC)",
                        new AccountRequest.Filter[]{PERSONAL_INFORMATION, CONTACT_INFORMATION},
                        new String[]{"personalInformation.firstName", "contactInformation.email"},
                        new String[]{"accountInformation", "addressInformation"}
                )
        );
    }
}
