package com.yape.validators;

import io.restassured.response.Response;
import org.assertj.core.api.AbstractAssert;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;
import static org.hamcrest.Matchers.*;

public class ResponseValidator extends AbstractAssert<ResponseValidator, Response> {
    
    private ResponseValidator(Response response) {
        super(response, ResponseValidator.class);
    }
    
    public static ResponseValidator assertThat(Response response) {
        return new ResponseValidator(response);
    }
    
    // ========== Schema Validations (Híbrido) ==========
    
    public ResponseValidator hasValidBaseStructure() {
        actual.then()
                .body(matchesJsonSchemaInClasspath("schemas/account-base-schema.json"));
        return this;
    }
    
    public ResponseValidator hasValidFullStructure() {
        actual.then()
                .body(matchesJsonSchemaInClasspath("schemas/account-full-schema.json"));
        return this;
    }
    
    public ResponseValidator hasValidErrorStructure() {
        actual.then()
                .body(matchesJsonSchemaInClasspath("schemas/error-response-schema.json"));
        return this;
    }
    
    // ========== Status Code Validations ==========
    
    public ResponseValidator hasStatusCode(int expectedStatus) {
        org.assertj.core.api.Assertions.assertThat(actual.statusCode())
                .as("Response status code")
                .isEqualTo(expectedStatus);
        return this;
    }
    
    public ResponseValidator isSuccess() {
        return hasStatusCode(200);
    }
    
    public ResponseValidator isBadRequest() {
        return hasStatusCode(400);
    }
    
    // ========== Field Presence Validations (Programático) ==========
    
    public ResponseValidator hasFields(String... fieldPaths) {
        for (String field : fieldPaths) {
            actual.then()
                    .body(field, notNullValue(),
                          "Field '" + field + "' should be present and not null");
        }
        return this;
    }
    
    public ResponseValidator doesNotHaveFields(String... fieldPaths) {
        for (String field : fieldPaths) {
            actual.then()
                    .body(field, anyOf(nullValue(), not(hasKey(extractFieldName(field)))),
                          "Field '" + field + "' should not be present or should be null");
        }
        return this;
    }
    
    // ========== Value Validations ==========
    
    public ResponseValidator hasFieldValue(String fieldPath, Object expectedValue) {
        actual.then()
                .body(fieldPath, equalTo(expectedValue));
        return this;
    }
    
    public ResponseValidator hasFieldMatching(String fieldPath, String regex) {
        actual.then()
                .body(fieldPath, matchesRegex(regex));
        return this;
    }
    
    // ========== Performance Validations ==========
    
    public ResponseValidator respondsWithinMillis(long maxMillis) {
        org.assertj.core.api.Assertions.assertThat(actual.time())
                .as("Response time")
                .isLessThan(maxMillis);
        return this;
    }
    
    public ResponseValidator respondsWithin5Seconds() {
        return respondsWithinMillis(5000);
    }
    
    // ========== Helper Methods ==========
    
    private String extractFieldName(String fieldPath) {
        String[] parts = fieldPath.split("\\.");
        return parts[parts.length - 1];
    }
}
