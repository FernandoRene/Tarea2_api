# 🚀 YAPE API Automation

Framework de automatización para APIs de YAPE usando RestAssured + JUnit5 con estrategia híbrida de schemas.

## ⚡ Quick Start

```bash
# 1. Instalar dependencias
mvn clean install -DskipTests

# 2. Ejecutar smoke tests
mvn test -Dgroups="smoke"

# 3. Ejecutar todos los tests
mvn test
```

## 📁 Estructura

```
src/
├── main/java/com/yape/
│   ├── clients/          # AccountClient, RemittanceClient
│   ├── models/           # DTOs (request/response)
│   ├── validators/       # ResponseValidator (fluent)
│   ├── builders/         # Test data builders
│   └── config/           # TestConfig singleton
└── test/
    ├── java/com/yape/
    │   ├── smoke/        # 3 tests críticos (~30 seg)
    │   ├── regression/   # 10-12 tests (~3-5 min)
    │   └── base/         # BaseTest, TestTags
    └── resources/
        ├── schemas/      # 3 schemas: base, full, error
        └── config/       # dev.properties, cert.properties
```

## 🎯 Estrategia Híbrida de Schemas

**3 schemas solamente:**
- `account-base-schema.json` → Estructura común (TODOS los tests)
- `account-full-schema.json` → Respuesta completa (test sin filtros)
- `error-response-schema.json` → Errores (tests de error)

**Validación programática:** Para filtros específicos (código en vez de schemas)

## 🧪 Niveles de Testing

### SMOKE (3 tests, ~30 seg)
```bash
mvn test -Dgroups="smoke"
```
- Sin filtros
- Filtro más común
- Error básico

### REGRESSION (12 tests, ~3-5 min)
```bash
mvn test -Dgroups="regression"
```
- 4 filtros individuales
- 3 combinaciones de negocio
- Edge cases

## 💻 Ejemplos de Uso

### Test Simple
```java
@Test
void getAccount_withPersonalInfo() {
    AccountRequest request = AccountRequestBuilder.aValidRequest()
            .withPersonalInfoFilter()
            .build();
    
    Response response = accountClient.getAccount(request);
    
    assertThat(response)
            .isSuccess()
            .hasValidBaseStructure()
            .hasFields("personalInformation.firstName")
            .doesNotHaveFields("contactInformation");
}
```

### Test con Builder Fluent
```java
AccountRequest request = AccountRequestBuilder.aValidRequest()
        .withFilters(PERSONAL_INFORMATION, CONTACT_INFORMATION)
        .build();
```

### Validación Híbrida
```java
// Schema base + validación programática de campos
assertThat(response)
        .hasValidBaseStructure()     // ← Schema
        .hasFields("firstName")       // ← Código
        .doesNotHaveFields("email");  // ← Código
```

## 🔧 Configuración

### Cambiar ambiente
```bash
mvn test -Denv=cert
mvn test -Denv=prod
```

### Ejecutar test específico
```bash
mvn test -Dtest=AccountSmokeTest
mvn test -Dtest=AccountFiltersRegressionTest#personalInformationOnly
```

### Tags disponibles
```bash
mvn test -Dgroups="smoke"           # Solo smoke
mvn test -Dgroups="regression"      # Solo regression
mvn test -Dgroups="account"         # Solo Account API
mvn test -Dgroups="smoke,account"   # Combinados
```

## 📊 Reportes Allure

```bash
# Generar y abrir reporte
mvn clean test allure:serve
```

## 🎨 Patrones Implementados

- **Builder Pattern**: Test data fluido
- **Fluent Assertions**: ResponseValidator
- **Singleton**: TestConfig
- **Strategy**: Schema híbrido (3 schemas + código)
- **Inheritance**: BaseClient → AccountClient

## 📋 Cobertura de Tests

| Nivel | Tests | Tiempo | Propósito |
|-------|-------|--------|-----------|
| Smoke | 3 | ~30s | Detectar si está roto |
| Regression | 12 | ~3-5min | Cobertura estratégica |
| Extended | TBD | TBD | Edge cases adicionales |

## 🚀 Escalabilidad

Para agregar nuevo endpoint:

1. Crear modelo en `models/`
2. Crear client en `clients/` heredando de `BaseClient`
3. Crear tests en `smoke/` y `regression/`
4. Agregar schema si es necesario

Ejemplo:
```java
public class RemittanceClient extends BaseClient {
    public RemittanceClient() {
        super(TestConfig.get().getRemittanceBasePath());
    }
    
    public Response validateRemittance(ValidateRequest request) {
        return post("/validate", request);
    }
}
```

## ✅ Checklist Pre-Commit

- [ ] Tests pasan localmente
- [ ] Smoke tests pasan
- [ ] No hay credenciales hardcoded
- [ ] Imports organizados
- [ ] Nombres descriptivos

## 🎯 Next Steps

1. Completar tests de Account API
2. Agregar RemittanceClient
3. Implementar tests de Remittance
4. Agregar CI/CD pipeline
5. Performance tests

---

**Stack:** RestAssured 5.4 | JUnit 5 | Allure | Lombok | AssertJ
