# 🚀 EMPIEZA AQUÍ

## 📚 Orden de Lectura Recomendado

### 1️⃣ PRIMERO (5 min)
→ **README.md** - Overview completo del proyecto

### 2️⃣ SEGUNDO (3 min)
→ **STRUCTURE.md** - Visualiza la estructura y patrones

### 3️⃣ TERCERO (2 min)
→ **COMMANDS.md** - Comandos para ejecutar tests

### 4️⃣ CUARTO (10 min)
→ **CHECKLIST.md** - Plan de implementación paso a paso

### 5️⃣ OPCIONAL
→ **docs/ADR.md** - Decisiones arquitectónicas clave

---

## ⚡ Quick Start (3 pasos)

```bash
# 1. Setup
mvn clean install -DskipTests

# 2. Configurar
# Edita: src/test/resources/config/dev.properties

# 3. Ejecutar
mvn test -Dtest=AccountSmokeTest
```

---

## 📁 Archivos Clave

### Documentación
- `README.md` → Todo sobre el proyecto
- `STRUCTURE.md` → Estructura visual
- `COMMANDS.md` → Comandos útiles
- `CHECKLIST.md` → Plan de implementación
- `docs/ADR.md` → Decisiones arquitectónicas

### Código Principal
- `src/main/java/com/yape/clients/AccountClient.java`
- `src/main/java/com/yape/validators/ResponseValidator.java`
- `src/main/java/com/yape/builders/AccountRequestBuilder.java`

### Tests
- `src/test/java/com/yape/smoke/AccountSmokeTest.java` ⭐
- `src/test/java/com/yape/regression/AccountFiltersRegressionTest.java` ⭐

### Schemas (Estrategia Híbrida)
- `src/test/resources/schemas/account-base-schema.json` ✅ Todos los tests
- `src/test/resources/schemas/account-full-schema.json` ✅ Test sin filtros
- `src/test/resources/schemas/error-response-schema.json` ✅ Tests error

### Configuración
- `pom.xml` → Dependencies
- `src/test/resources/config/dev.properties` → Config desarrollo

---

## 🎯 Lo Más Importante

### Estrategia Híbrida = 3 Schemas + Código

**POR QUÉ:**
- ✅ Compliance (schemas para auditoría)
- ✅ Mantenible (solo 3 archivos, no 15+)
- ✅ Flexible (código para filtros específicos)

**CÓMO:**
```java
assertThat(response)
    .hasValidBaseStructure()     // ← Schema
    .hasFields("firstName")       // ← Código
    .doesNotHaveFields("email");  // ← Código
```

---

## 📊 Tests Implementados

### SMOKE (3 tests, ~30 seg)
✅ Sin filtros
✅ Filtro más común
✅ Error básico

### REGRESSION (12 tests, ~3-5 min)
✅ 4 filtros individuales
✅ 3 combinaciones de negocio
✅ 2 edge cases
✅ Tests parametrizados

---

## 🔧 Stack Tecnológico

- **RestAssured 5.4** → API testing
- **JUnit 5** → Test framework
- **Allure** → Reportes
- **Lombok** → Reduce boilerplate
- **AssertJ** → Assertions fluidas

---

## 🎨 Patrones Implementados

1. **Builder Pattern** → AccountRequestBuilder
2. **Fluent API** → ResponseValidator
3. **Singleton** → TestConfig
4. **Inheritance** → BaseClient → AccountClient
5. **Strategy** → Híbrido schemas + código

---

## ✨ Características Destacadas

✅ Multi-ambiente (dev, cert, prod)
✅ Tests selectivos (no todas las combinaciones)
✅ Validación híbrida (schemas + código)
✅ Builders fluent
✅ Reportes Allure
✅ Tags para organización
✅ Escalable para más APIs

---

## 🚀 Próximos Pasos

1. ✅ **Lee README.md** (5 min)
2. ✅ **Ejecuta AccountSmokeTest** (2 min)
3. ✅ **Lee CHECKLIST.md** (10 min)
4. ✅ **Ajusta config/dev.properties** (5 min)
5. ✅ **Ejecuta suite completa** (3-5 min)

---

## 💡 Tip

**Empieza por ejecutar los tests ANTES de leer todo el código.**
Ver los tests en acción te ayudará a entender mejor la estructura.

```bash
# Ejecuta esto AHORA:
mvn test -Dtest=AccountSmokeTest

# Luego abre el reporte:
mvn allure:serve
```

---

**¡Todo está listo para usar! 🎉**

La estructura está implementada, los tests funcionan, y tienes un plan claro de cómo continuar.
