package com.yape.base;

import com.yape.clients.AccountClient;
import com.yape.config.TestConfig;
import io.qameta.allure.Allure;
import org.junit.jupiter.api.BeforeEach;

public abstract class BaseTest {
    
    protected TestConfig config;
    protected AccountClient accountClient;
    
    @BeforeEach
    public void setUp() {
        config = TestConfig.get();
        accountClient = new AccountClient();
        
        // Agregar información del ambiente a Allure
        Allure.addAttachment("Environment", config.getEnvironment());
        Allure.addAttachment("Base URL", config.getBaseUrl());
    }
}
