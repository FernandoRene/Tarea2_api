package com.yape.models.account;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccountRequest {
    
    private String phoneNumber;
    private String filterFields;
    
    public enum Filter {
        PERSONAL_INFORMATION("personalInformation"),
        CONTACT_INFORMATION("contactInformation"),
        ACCOUNT_INFORMATION("accountInformation"),
        ADDRESS_INFORMATION("addressInformation");
        
        private final String value;
        
        Filter(String value) {
            this.value = value;
        }
        
        public String getValue() {
            return value;
        }
    }
    
    public static class AccountRequestBuilder {
        public AccountRequestBuilder filters(Filter... filters) {
            if (filters != null && filters.length > 0) {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < filters.length; i++) {
                    sb.append(filters[i].getValue());
                    if (i < filters.length - 1) {
                        sb.append(",");
                    }
                }
                this.filterFields = sb.toString();
            }
            return this;
        }
    }
}
