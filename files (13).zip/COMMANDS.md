# ⚡ Comandos Esenciales

## Setup Inicial

```bash
# Clonar/copiar proyecto
cd automation-yape

# Instalar dependencias
mvn clean install -DskipTests

# Verificar compilación
mvn clean compile
```

## Ejecutar Tests

```bash
# Todos los tests (ambiente dev por defecto)
mvn test

# Smoke tests (3 tests, ~30 segundos)
mvn test -Dgroups="smoke"

# Regression tests (12 tests, ~3-5 minutos)
mvn test -Dgroups="regression"

# Solo Account API
mvn test -Dgroups="account"

# Ambiente específico
mvn test -Denv=cert
mvn test -Denv=prod
```

## Tests Específicos

```bash
# Clase completa
mvn test -Dtest=AccountSmokeTest
mvn test -Dtest=AccountFiltersRegressionTest

# Método específico
mvn test -Dtest=AccountSmokeTest#getAccount_withoutFilters_returnsCompleteInfo

# Nested class
mvn test -Dtest=AccountFiltersRegressionTest\$IndividualFilters
```

## Reportes

```bash
# Generar reporte Allure
mvn clean test
mvn allure:report

# Abrir reporte en navegador
mvn allure:serve

# Todo en un comando
mvn clean test allure:serve
```

## IntelliJ IDEA

```bash
# Habilitar Lombok
File → Settings → Plugins → Lombok → Install
File → Settings → Build → Compiler → Annotation Processors
  ☑ Enable annotation processing

# Ejecutar test
Click derecho en test → Run
O: Ctrl+Shift+F10 (Windows) / Cmd+Shift+R (Mac)

# Debug
Click derecho → Debug
Breakpoint: Click en línea lateral
F8: Step over
F7: Step into
```

## Verificación Rápida

```bash
# Verificar que todo funciona
mvn clean test -Dtest=AccountSmokeTest -Dgroups="smoke"

# Si pasa = ✅ Setup correcto
# Si falla = ❌ Revisar config/dev.properties
```

## Tips

```bash
# Logs detallados
mvn test -X

# Sin logs (solo resultados)
mvn test -q

# Skip tests (solo compilar)
mvn clean install -DskipTests

# Limpiar todo
mvn clean
```

## Estructura de Carpetas

```bash
# Ver estructura
tree src/

# Contar tests
find src/test -name "*Test.java" | wc -l

# Ver schemas
ls -la src/test/resources/schemas/
```

## Debug Rápido

```bash
# Ver configuración cargada
cat src/test/resources/config/dev.properties

# Ver schemas
cat src/test/resources/schemas/account-base-schema.json

# Ver logs del último test
tail -f target/surefire-reports/*.txt
```
