@allure.label.quiteallure:true
Feature: Endpoint YAPE Business Remittance Payout – validate

  Como Core Remesas BCP,
  Quiero validar el status del yapero y la información de la remesa,
  Para garantizar que el beneficiario y el monto son correctos antes de acreditar.

  Background:
    * configure report = false
    * def date = Java.type('qa.tools.date.DateUtil')
    * def uuid = Java.type('qa.tools.id.UuidUtil')

  Scenario: POST validate – Business Remittance Payout
    Given url props['intranet.remittance.urls.payout']
    And   path resolvePathIntranet('remittance', 'payout', 'validate')
    And   header content-type    = 'application/json'
    And   header authorization   = auth.authorization
    And   header channel         = auth.channel
    And   header AppUserId       = auth.appUserId
    And   header PublicToken     = auth.publicToken
    And   header x-correlation-id = uuid.getUuid()
    And   header request-date    = date.currentDateFormatted()
    And   request bodyRequest
    When  method POST
