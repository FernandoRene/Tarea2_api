# 🥒 Features BDD - Validate Remittance

## 📁 Estructura de Features

```
features/
├── smoke/                              # 3 escenarios críticos (~2 min)
│   └── validate-smoke.feature
│
├── regression/                         # 30+ escenarios (~15-20 min)
│   ├── validate-beneficiary.feature    # 7 escenarios
│   ├── validate-amounts.feature        # 9 escenarios
│   ├── validate-currency.feature       # 7 escenarios
│   └── validate-mandatory-fields.feature # 8 escenarios
│
└── extended/                           # 20+ escenarios (~20-30 min)
    ├── validate-edge-cases.feature     # 13 escenarios
    └── validate-performance-security.feature # 11 escenarios
```

---

## 🎯 Resumen de Casos de Prueba

### SMOKE (3 escenarios - CRÍTICOS)
✅ **validate-smoke.feature**
1. Validación exitosa con datos completos
2. Beneficiario no existe
3. Campos obligatorios faltantes

**Tags:** `@smoke`, `@critical`
**Tiempo estimado:** ~2 minutos

---

### REGRESSION (31 escenarios - ALTA PRIORIDAD)

#### **validate-beneficiary.feature** (7 escenarios)
- Documento no coincide
- Tipo de documento inválido
- Sin cuenta BOB activa
- Teléfono inválido
- Código de país inválido
- Diferentes tipos de documento (Scenario Outline)

**Tags:** `@regression`, `@high`

#### **validate-amounts.feature** (9 escenarios)
- Excede límite por transacción
- Excede límite diario beneficiario
- Excede límite mensual beneficiario
- Excede límite diario remitente
- Excede límite mensual remitente
- Monto con decimales
- Diferentes montos (Scenario Outline)
- Monto en centavos

**Tags:** `@regression`, `@high`, `@limits`

#### **validate-currency.feature** (7 escenarios)
- Moneda no soportada
- Moneda correcta (BOB)
- Conversión USD a BOB
- Falta exchangeRate
- ExchangeRate no necesario
- Diferentes monedas (Scenario Outline)
- Conversión con múltiples monedas

**Tags:** `@regression`, `@high`, `@currency`

#### **validate-mandatory-fields.feature** (8 escenarios)
- Falta campo de remitente (Outline)
- Falta campo de beneficiario (Outline)
- Falta campo de paymentInfo (Outline)
- B2C requiere category
- ExchangeRate obligatorio
- Solo campos obligatorios
- Tipo de dato incorrecto

**Tags:** `@regression`, `@high`, `@mandatory-fields`

**Tiempo estimado:** ~15-20 minutos

---

### EXTENDED (24 escenarios - MEDIA/BAJA PRIORIDAD)

#### **validate-edge-cases.feature** (13 escenarios)
- EndToEndId duplicado
- Campos opcionales nulos
- Longitud máxima
- Caracteres especiales
- Tildes y eñes
- Tipos de canal (Outline)
- Remesadoras (Outline)
- Múltiples espacios
- Mayúsculas/minúsculas
- Fecha futura
- Mayor de 100 años
- Empresa (B2C)

**Tags:** `@extended`, `@medium`, `@edge-case`

#### **validate-performance-security.feature** (11 escenarios)
- Timeout 5 segundos
- Validaciones concurrentes
- Carga (100 requests)
- SQL Injection (Outline)
- XSS (Outline)
- Headers de seguridad
- Token inválido/faltante
- HTTPS
- Privacidad de datos
- Disponibilidad 24h

**Tags:** `@extended`, `@medium`, `@performance`, `@security`

**Tiempo estimado:** ~20-30 minutos

---

## 📊 Matriz de Tags

### Por Nivel
```bash
@smoke          # 3 escenarios
@regression     # 31 escenarios
@extended       # 24 escenarios
```

### Por Prioridad
```bash
@critical       # 2 escenarios
@high           # 25 escenarios
@medium         # 25 escenarios
@low            # 6 escenarios
```

### Por Categoría
```bash
@beneficiary    # Validación de beneficiario
@amounts        # Validación de montos
@limits         # Límites de transacciones
@currency       # Validación de moneda
@conversion     # Conversión de moneda
@mandatory-fields # Campos obligatorios
@edge-case      # Casos extremos
@performance    # Performance
@security       # Seguridad
@data-privacy   # Privacidad de datos
```

---

## 🚀 Ejecución de Features

### Ejecutar por nivel
```bash
# Solo smoke
mvn test -Dcucumber.filter.tags="@smoke"

# Solo regression
mvn test -Dcucumber.filter.tags="@regression"

# Solo extended
mvn test -Dcucumber.filter.tags="@extended"
```

### Ejecutar por prioridad
```bash
# Solo críticos
mvn test -Dcucumber.filter.tags="@critical"

# Alta prioridad
mvn test -Dcucumber.filter.tags="@high"
```

### Ejecutar por categoría
```bash
# Solo validación de beneficiario
mvn test -Dcucumber.filter.tags="@beneficiary"

# Solo validación de montos
mvn test -Dcucumber.filter.tags="@amounts"

# Solo seguridad
mvn test -Dcucumber.filter.tags="@security"
```

### Combinar tags
```bash
# Regression de alta prioridad
mvn test -Dcucumber.filter.tags="@regression and @high"

# Smoke + Critical
mvn test -Dcucumber.filter.tags="@smoke or @critical"

# No extended
mvn test -Dcucumber.filter.tags="not @extended"
```

---

## 📋 Cobertura Total

| Nivel      | Features | Escenarios | Tiempo Estimado |
|------------|----------|------------|-----------------|
| Smoke      | 1        | 3          | ~2 min          |
| Regression | 4        | 31         | ~15-20 min      |
| Extended   | 2        | 24         | ~20-30 min      |
| **TOTAL**  | **7**    | **58**     | **~40-50 min**  |

---

## 🎨 Estructura de Scenario

Todos los scenarios siguen el patrón:
```gherkin
Scenario: Descripción clara del caso
  Given [Precondiciones]
  And [Más precondiciones]
  When [Acción]
  Then [Resultado esperado]
  And [Validaciones adicionales]
```

---

## 📝 Convenciones

### Naming
- Features: `validate-[categoria].feature`
- Scenarios: Descripción en español, clara y concisa
- Tags: lowercase, con guiones

### Background
Todos los features tienen un Background común con:
- Endpoint disponible
- Headers configurados

### Scenario Outline
Usado para casos parametrizados:
- Diferentes tipos de documento
- Diferentes montos
- Diferentes monedas
- SQL Injection/XSS payloads

---

## ✅ Casos de Uso Cubiertos

### Happy Paths ✅
- Validación exitosa completa
- Con conversión de moneda
- Con remitente empresa
- Con diferentes canales

### Unhappy Paths ✅
- Beneficiario no existe
- Documentos no coinciden
- Montos exceden límites
- Moneda no soportada
- Campos obligatorios faltantes

### Edge Cases ✅
- Caracteres especiales
- Longitud máxima
- EndToEndId duplicado
- Campos opcionales nulos

### Security ✅
- SQL Injection
- XSS
- Headers faltantes
- Token inválido

### Performance ✅
- Timeout
- Concurrencia
- Carga

---

## 🎯 Próximos Pasos

1. **Implementar Step Definitions**
   - ValidateSteps.java
   - CommonSteps.java
   - TestContext.java

2. **Configurar Cucumber**
   - Runner class
   - cucumber.properties
   - Hooks

3. **Integrar con Framework Existente**
   - Reutilizar AccountClient pattern
   - Crear RemittanceClient
   - Validadores

4. **Reportes**
   - Cucumber Reports
   - Allure integration
   - Screenshots en fallos

---

## 📚 Documentación para Stakeholders

Estos features están escritos en **lenguaje natural** y pueden ser:
- ✅ Leídos por Product Owners
- ✅ Revisados por Business Analysts
- ✅ Aprobados por equipos de negocio
- ✅ Usados como documentación viva

**Los features BDD sirven como:**
1. Especificación ejecutable
2. Documentación del sistema
3. Casos de prueba automatizados
4. Validación de requerimientos
