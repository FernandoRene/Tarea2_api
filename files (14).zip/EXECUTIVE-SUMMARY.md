# 📋 Resumen Ejecutivo - Casos de Prueba BDD

## 🎯 Cobertura Total: 58 Escenarios

---

## 🔥 NIVEL 1: SMOKE TESTS (3 escenarios)

### validate-smoke.feature

| ID | Escenario | Prioridad | Tags |
|----|-----------|-----------|------|
| TC-01 | Validación exitosa con todos los datos correctos | CRÍTICA | @critical @happy-path |
| TC-02 | Validación rechazada - Beneficiario no existe | CRÍTICA | @critical @error-handling |
| TC-03 | Validación rechazada - Campos obligatorios faltantes | CRÍTICA | @critical @error-handling |

**Tiempo estimado:** 2 minutos

---

## 📊 NIVEL 2: REGRESSION TESTS (31 escenarios)

### validate-beneficiary.feature (7 escenarios)

| ID | Escenario | Error Esperado | Prioridad |
|----|-----------|----------------|-----------|
| TC-04 | Documento de beneficiario no coincide | YP-RM-0002 | ALTA |
| TC-05 | Tipo de documento inválido | YP-RM-0002/0004 | ALTA |
| TC-06 | Beneficiario no tiene cuenta BOB activa | YP-RM-0003 | ALTA |
| TC-07 | Número de teléfono inválido | YP-RM-0003 | ALTA |
| TC-08 | Código de país inválido | YP-RM-0003 | MEDIA |
| TC-09 | Validación con DNI | 200 OK | MEDIA |
| TC-10 | Validación con PASS | 200 OK | MEDIA |

### validate-amounts.feature (9 escenarios)

| ID | Escenario | Error Esperado | Prioridad |
|----|-----------|----------------|-----------|
| TC-11 | Monto excede límite por transacción | YP-RM-0005 | ALTA |
| TC-12 | Monto excede límite diario beneficiario | YP-RM-0008 | ALTA |
| TC-13 | Monto excede límite mensual beneficiario | YP-RM-0009 | MEDIA |
| TC-14 | Monto excede límite diario remitente | YP-RM-0010 | ALTA |
| TC-15 | Monto excede límite mensual remitente | YP-RM-0011 | MEDIA |
| TC-16 | Monto con decimales válidos (100.50) | 200 OK | MEDIA |
| TC-17 | Monto mínimo (1) | 200 OK | ALTA |
| TC-18 | Monto cero (0) | 400 | ALTA |
| TC-19 | Monto en centavos procesado correctamente | 200 OK | MEDIA |

### validate-currency.feature (7 escenarios)

| ID | Escenario | Error Esperado | Prioridad |
|----|-----------|----------------|-----------|
| TC-20 | Moneda no soportada (EUR) | YP-RM-0006 | ALTA |
| TC-21 | Moneda correcta (BOB) | 200 OK | ALTA |
| TC-22 | Conversión USD a BOB válida | 200 OK | ALTA |
| TC-23 | Falta exchangeRate cuando monedas difieren | 400 | MEDIA |
| TC-24 | ExchangeRate no necesario (misma moneda) | 200 OK | MEDIA |
| TC-25 | Validación con USD (no permitida) | 400 | MEDIA |
| TC-26 | Conversión con múltiples monedas | 200 OK | ALTA |

### validate-mandatory-fields.feature (8 escenarios)

| ID | Escenario | Error Esperado | Prioridad |
|----|-----------|----------------|-----------|
| TC-27 | Falta sender.fullName | YP-RM-0004 | ALTA |
| TC-28 | Falta beneficiary.fullName | YP-RM-0004 | ALTA |
| TC-29 | Falta paymentInfo.accountNumber | YP-RM-0004 | CRÍTICA |
| TC-30 | Falta paymentInfo.endToEndId | YP-RM-0004 | CRÍTICA |
| TC-31 | B2C sin category | YP-RM-0004 | ALTA |
| TC-32 | ExchangeRate obligatorio cuando monedas difieren | 400 | ALTA |
| TC-33 | Validación con solo campos obligatorios | 200 OK | MEDIA |
| TC-34 | Tipo de dato incorrecto (amount como string) | YP-RM-0004 | MEDIA |

**Tiempo estimado:** 15-20 minutos

---

## 🔧 NIVEL 3: EXTENDED TESTS (24 escenarios)

### validate-edge-cases.feature (13 escenarios)

| ID | Escenario | Prioridad |
|----|-----------|-----------|
| TC-35 | EndToEndId duplicado | MEDIA |
| TC-36 | Campos opcionales todos nulos | MEDIA |
| TC-37 | Longitud máxima de campos (100 chars) | MEDIA |
| TC-38 | Nombres con caracteres especiales (José María O'Connor) | MEDIA |
| TC-39 | Nombres con tildes y eñes | MEDIA |
| TC-40 | ChannelType: ONLINE | MEDIA |
| TC-41 | ChannelType: BRANCH_OFFICES | MEDIA |
| TC-42 | Remesadora RIA | MEDIA |
| TC-43 | Remesadora WU | MEDIA |
| TC-44 | Múltiples espacios en nombres | MEDIA |
| TC-45 | Mayúsculas/minúsculas mezcladas | MEDIA |
| TC-46 | Fecha de nacimiento futura | BAJA |
| TC-47 | Beneficiario mayor de 100 años | BAJA |
| TC-48 | Sender es empresa (B2C) | MEDIA |

### validate-performance-security.feature (11 escenarios)

| ID | Escenario | Categoría | Prioridad |
|----|-----------|-----------|-----------|
| TC-49 | Tiempo de respuesta < 5 segundos | Performance | MEDIA |
| TC-50 | 10 validaciones concurrentes | Performance | MEDIA |
| TC-51 | Carga de 100 requests en 1 minuto | Performance | BAJA |
| TC-52 | SQL Injection - DROP TABLE | Security | ALTA |
| TC-53 | SQL Injection - OR 1=1 | Security | ALTA |
| TC-54 | XSS - script tag | Security | ALTA |
| TC-55 | Headers de seguridad faltantes | Security | MEDIA |
| TC-56 | Token de autorización inválido | Security | MEDIA |
| TC-57 | Token de autorización faltante | Security | MEDIA |
| TC-58 | HTTPS obligatorio | Security | BAJA |

**Tiempo estimado:** 20-30 minutos

---

## 📈 Distribución por Prioridad

| Prioridad | Cantidad | Porcentaje |
|-----------|----------|------------|
| CRÍTICA   | 5        | 9%         |
| ALTA      | 25       | 43%        |
| MEDIA     | 24       | 41%        |
| BAJA      | 4        | 7%         |
| **TOTAL** | **58**   | **100%**   |

---

## 🎯 Distribución por Categoría

| Categoría | Escenarios |
|-----------|------------|
| Validación de Beneficiario | 7 |
| Validación de Montos | 9 |
| Validación de Moneda | 7 |
| Campos Obligatorios | 8 |
| Edge Cases | 13 |
| Performance | 3 |
| Security | 8 |
| Happy Paths | 3 |
| **TOTAL** | **58** |

---

## 📊 Cobertura de Códigos de Error

| Código Error | Escenarios | Descripción |
|--------------|------------|-------------|
| YP-RM-0002 | 2 | Receiver information does not match |
| YP-RM-0003 | 4 | Wallet is invalid |
| YP-RM-0004 | 10 | Mandatory information is missing |
| YP-RM-0005 | 1 | Transaction amount limit exceeds |
| YP-RM-0006 | 2 | Payout currency is not supported |
| YP-RM-0008 | 1 | Maximum transaction amount per day |
| YP-RM-0009 | 1 | Maximum transaction amount per month |
| YP-RM-0010 | 1 | Maximum amount per day sender |
| YP-RM-0011 | 1 | Maximum amount per month sender |

**Total de códigos de error cubiertos:** 9 de 9 (100%)

---

## ✅ Checklist de Implementación

### Fase 1: SMOKE (Crítico)
- [ ] TC-01: Happy path completo
- [ ] TC-02: Beneficiario no existe
- [ ] TC-03: Campos faltantes

### Fase 2: REGRESSION - Alta Prioridad (15 escenarios)
- [ ] TC-04 a TC-10: Validación beneficiario
- [ ] TC-11, TC-12, TC-14: Límites críticos
- [ ] TC-17, TC-18: Montos límite
- [ ] TC-20, TC-21, TC-22: Validación moneda
- [ ] TC-29, TC-30, TC-31: Campos obligatorios críticos

### Fase 3: REGRESSION - Media Prioridad (16 escenarios)
- [ ] Resto de validación de montos
- [ ] Resto de validación de moneda
- [ ] Resto de campos obligatorios

### Fase 4: EXTENDED
- [ ] Edge cases (13 escenarios)
- [ ] Performance (3 escenarios)
- [ ] Security (8 escenarios)

---

## 🚀 Ejecución Sugerida

### Pipeline CI/CD

**Commit → Smoke (2 min)**
```bash
mvn test -Dcucumber.filter.tags="@smoke"
```

**Nightly → Regression (15-20 min)**
```bash
mvn test -Dcucumber.filter.tags="@regression"
```

**Pre-Release → Full Suite (40-50 min)**
```bash
mvn test
```

---

## 📝 Notas Importantes

### Casos que Requieren Definición de Negocio
1. **TC-35:** Comportamiento con endToEndId duplicado
2. **TC-47:** Política de edad máxima (>100 años)
3. **TC-12 a TC-15:** Límites exactos por día/mes

### Casos que Requieren Environment Específico
1. **TC-50 a TC-51:** Performance tests (ambiente de carga)
2. **TC-52 a TC-54:** Security tests (ambiente de seguridad)

### Datos de Prueba Necesarios
1. Beneficiario válido registrado en YAPE
2. Beneficiario sin cuenta BOB
3. Tipos de cambio actualizados
4. Límites configurados por ambiente

---

## 📞 Contacto para Dudas

- **Casos de negocio:** Product Owner
- **Límites y políticas:** Risk Management
- **Datos de prueba:** QA Lead
- **Implementación técnica:** Tech Lead

---

**Última actualización:** Diciembre 2024
**Versión:** 1.0.0
