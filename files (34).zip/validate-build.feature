@allure.label.quiteallure:true
Feature: Constructor dinámico de payload – validate

  Background:
    * configure report = false
    * def buildValidatePayload =
      """
      function(basicRequest, rulesJson, ruleType, ruleName) {
        var payload = JSON.parse(JSON.stringify(basicRequest));
        var overrides = rulesJson[ruleType][ruleName] || {};

        for (var field in overrides) {
          var value = overrides[field];

          if (field === 'sender' || field === 'beneficiary' || field === 'paymentInfo') {
            if (!payload[field]) payload[field] = {};
            for (var subField in value) {
              if (value[subField] !== null && value[subField] !== undefined && value[subField] !== '') {
                payload[field][subField] = value[subField];
              } else if (value[subField] === null) {
                delete payload[field][subField];
              }
            }
          } else {
            if (value !== null && value !== undefined && value !== '') {
              payload[field] = value;
            } else if (value === null) {
              delete payload[field];
            }
          }
        }
        return { data: payload };
      }
      """

  Scenario: Construcción de payload validate dinámico
    * def validate = buildValidatePayload(basicRequest, rulesJson, ruleType, ruleName)
