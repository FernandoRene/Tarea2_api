@allure.label.quiteallure:true
Feature: Obtención de token IAM para servicios intranet remesas

  Como consumidor de los servicios internos de remesas,
  Quiero autenticar mis solicitudes mediante token IAM,
  Para garantizar el acceso seguro a los endpoints de la red intranet.

  Background:
    * configure report = false
    * def date    = Java.type('qa.tools.date.DateUtil')
    * def uuid    = Java.type('qa.tools.id.UuidUtil')
    * def iamUrl  = props['urls.intranet.remesas.iam']
    * def channel = props['headers.intranet.remesas.channel']

  Scenario: Generación de token IAM
    Given url iamUrl
    And header Content-Type  = 'application/json'
    And header X-Correlation-Id = uuid.getUuid()
    And request iamRequest
    When method POST
    Then status 200
    * def iamToken = response.access_token
