package runners.intranet.remesas;

import intranet.remesas.payout.prepareData.PayoutHook;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.IOException;

class PayoutRunnerIT {

    @BeforeAll
    static void globalSetup() {
        // Setup previo a la suite si se requiere
        // Ejemplo: pre-carga de datos, validación de conectividad IAM
    }

    @Test
    void runTestSuite() {
        PayoutHook.executePayoutSuite();
    }

    @AfterAll
    static void globalTearDown() throws IOException {
        PayoutHook.tearDown();
    }
}
