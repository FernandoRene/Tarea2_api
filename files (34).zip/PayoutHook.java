package intranet.remesas.payout.prepareData;

import com.intuit.karate.Results;
import qa.tools.allure.AllureReportReader;
import qa.tools.file.FileUtil;
import qa.tools.runner.KarateExecutionUtil;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class PayoutHook {

    public static void tearDown() throws IOException {
        AllureReportReader reader = new AllureReportReader(
                "target/allure-report/widgets",
                "target/allure-results"
        );

        reader.deleteLabelIgnore();

        if (reader.countFilesAllure() >= 1) {
            FileUtil.copyFile("src/test/resources/allure", "target/allure-results", "environment.properties");
            FileUtil.copyFile("src/test/resources/allure", "target/allure-results", "categories.json");
            FileUtil.copyFile("src/test/resources/allure", "target/allure-results", "executor.json");
            reader.generateReport();

            Path executionDir = Paths.get(
                    "target", "zip",
                    qa.tools.date.DateUtil.today(),
                    qa.tools.date.DateUtil.timestamp()
            );
            Files.createDirectories(executionDir);
            FileUtil.copyDirectory("target/allure-report/", executionDir + "/allure-report");
            FileUtil.copyDirectory("target/karate-reports/", executionDir + "/karate-reports");
            FileUtil.copyFile("src/test/resources/bat", executionDir.toString(), "index.bat");
        }
    }

    public static void executePayoutSuite() {
        int failures = 0;
        failures += runValidate();
        failures += runCreate();
        failures += runInquire();
        assert failures == 0;
    }

    // ──────────────────────────────────────────────────────────────────────
    // Métodos privados por endpoint – permiten ejecutar cada uno de forma
    // independiente desde el runner o desde CI/CD con tags específicos
    // ──────────────────────────────────────────────────────────────────────

    private static int runValidate() {
        Results result = KarateExecutionUtil.runner(
                "classpath:intranet/remesas/payout/feature/orchestrators/functional/validate-orchestrator.feature",
                "target/karate-reports/intranet/remesas/payout/validate",
                1,
                null,
                "@validate"
        );
        return result.getFailCount();
    }

    private static int runCreate() {
        Results result = KarateExecutionUtil.runner(
                "classpath:intranet/remesas/payout/feature/orchestrators/functional/create-orchestrator.feature",
                "target/karate-reports/intranet/remesas/payout/create",
                1,
                null,
                "@create"
        );
        return result.getFailCount();
    }

    private static int runInquire() {
        Results result = KarateExecutionUtil.runner(
                "classpath:intranet/remesas/payout/feature/orchestrators/functional/inquire-orchestrator.feature",
                "target/karate-reports/intranet/remesas/payout/inquire",
                1,
                null,
                "@inquire"
        );
        return result.getFailCount();
    }
}
