@allure.label.quiteallure:true
Feature: Endpoint YAPE Business Remittance Payout – validate

  Como Core Remesas BCP,
  Quiero validar el status del yapero y la información de la remesa,
  Para garantizar que el beneficiario y el monto son correctos antes de acreditar.

  Background:
    * configure report = false
    * def date = Java.type('qa.tools.date.DateUtil')
    * def uuid = Java.type('qa.tools.id.UuidUtil')
    * def channel = props['headers.intranet.remesas.channel']

  Scenario: POST validate – Business Remittance Payout
    Given url urls.intranetRemesas.payout
    And   path resolvePathRemesas('payout', 'validate')
    And   header Content-Type    = 'application/json'
    And   header Channel         = channel
    And   header X-Correlation-Id = uuid.getUuid()
    And   header Request-Date    = date.currentDateFormatted()
    And   header Authorization   = 'Bearer ' + iamToken
    And   request bodyRequest
    When  method POST
